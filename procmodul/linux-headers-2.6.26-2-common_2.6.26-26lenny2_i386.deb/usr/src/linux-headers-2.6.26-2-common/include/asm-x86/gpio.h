#ifndef _ASM_I386_GPIO_H
#define _ASM_I386_GPIO_H

#include <gpio.h>

#endif /* _ASM_I386_GPIO_H */
