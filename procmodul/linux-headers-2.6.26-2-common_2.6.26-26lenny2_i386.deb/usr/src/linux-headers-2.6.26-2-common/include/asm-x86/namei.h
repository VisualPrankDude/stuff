#ifndef _ASM_X86_NAMEI_H
#define _ASM_X86_NAMEI_H

/* This dummy routine maybe changed to something useful
 * for /usr/gnemul/ emulation stuff.
 * Look at asm-sparc/namei.h for details.
 */

#define __emul_prefix() NULL

#endif /* _ASM_X86_NAMEI_H */
