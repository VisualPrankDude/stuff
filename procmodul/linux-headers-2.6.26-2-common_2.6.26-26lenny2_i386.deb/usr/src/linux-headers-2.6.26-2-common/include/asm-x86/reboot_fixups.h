#ifndef _LINUX_REBOOT_FIXUPS_H
#define _LINUX_REBOOT_FIXUPS_H

extern void mach_reboot_fixups(void);

#endif /* _LINUX_REBOOT_FIXUPS_H */
