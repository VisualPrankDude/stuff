#ifdef CONFIG_X86_32
# include "genapic_32.h"
#else
# include "genapic_64.h"
#endif
