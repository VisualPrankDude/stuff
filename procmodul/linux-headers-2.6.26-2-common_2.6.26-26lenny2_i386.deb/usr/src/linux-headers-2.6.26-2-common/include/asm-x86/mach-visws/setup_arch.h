/* Hook to call BIOS initialisation function */

extern unsigned long sgivwfb_mem_phys;
extern unsigned long sgivwfb_mem_size;

/* no action for visws */

#define ARCH_SETUP
