/* Hook to call BIOS initialisation function */

/* no action for generic */

#ifndef ARCH_SETUP
#define ARCH_SETUP
#endif
