#ifndef _ASM_X86_BUGS_H
#define _ASM_X86_BUGS_H

extern void check_bugs(void);
int ppro_with_ram_bug(void);

#endif /* _ASM_X86_BUGS_H */
