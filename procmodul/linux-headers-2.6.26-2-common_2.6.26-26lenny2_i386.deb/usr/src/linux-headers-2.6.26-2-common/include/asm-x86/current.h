#ifdef CONFIG_X86_32
# include "current_32.h"
#else
# include "current_64.h"
#endif
