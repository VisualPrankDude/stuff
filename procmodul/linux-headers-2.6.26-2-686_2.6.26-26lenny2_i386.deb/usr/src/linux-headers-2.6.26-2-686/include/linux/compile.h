/* This file is auto generated, version 1 */
/* SMP */
#define UTS_MACHINE "i386"
#define UTS_VERSION "#1 SMP Thu Jan 27 00:28:05 UTC 2011"
#define LINUX_COMPILE_TIME "00:28:05"
#define LINUX_COMPILE_DISTRIBUTION "Debian"
#define LINUX_COMPILE_DISTRIBUTION_OFFICIAL_BUILD
#define LINUX_COMPILE_DISTRIBUTION_UPLOADER "dannf@debian.org"
#define LINUX_COMPILE_DISTRIBUTION_VERSION "2.6.26-26lenny2"
#define LINUX_COMPILE_BY "unknown"
#define LINUX_COMPILE_HOST "Debian"
#define LINUX_COMPILE_DOMAIN
#define LINUX_COMPILER "gcc version 4.1.3 20080704 (prerelease) (Debian 4.1.2-25)"
